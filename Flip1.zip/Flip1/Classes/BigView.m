//
//  BigView.m
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BigView.h"
#import "LittleView0.h"
#import "LittleView1.h"
#import "LittleView2.h"

@implementation BigView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        views = [NSArray arrayWithObjects:
				 [[LittleView0 alloc] initWithFrame: self.bounds],
				 [[LittleView1 alloc] initWithFrame: self.bounds],
				 [[LittleView2 alloc] initWithFrame: self.bounds],
				 nil
				 ];
		
		[views retain];
		
		index = 1; 
		[self addSubview: [views objectAtIndex: index]];
		
		pointBegan = CGPointZero;
		pointMoved = CGPointZero;
    }
    return self;
}


- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	NSAssert1(touches.count > 0,
			  @"touchesBegan:withEvent: touches.count == %u", touches.count);
	
	UITouch *t = [touches anyObject];
	pointBegan = [t locationInView: self];
	timeBegan = t.timestamp;
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	NSAssert1(touches.count > 0,
			  @"touchesMoved:withEvent: touches.count == %u", touches.count);
	
	UITouch *t = [touches anyObject];
	pointMoved = [t locationInView: self];
	timeMoved = t.timestamp;
	//[self setNeedsDisplay];
}

-(void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event{
	int newIndex; // = index;
	
	CGFloat horizontal = pointMoved.x - pointBegan.x;
	CGFloat vertical = pointMoved.y - pointBegan.y;
	CGFloat distance = hypotf(horizontal, vertical);
//	CGFloat angle = atan2f(-vertical, horizontal) * 180 / M_PI;
//	CGFloat duration = timeMoved - timeBegan;
	
	if (distance > 50 && horizontal < 0) {		//left swipe
		newIndex = MAX(0, index - 1);
		
		if (index != newIndex){		
			[UIView transitionFromView: [views objectAtIndex: index]
							toView: [views objectAtIndex: newIndex]
						  duration: 2
						   options: UIViewAnimationOptionTransitionFlipFromRight
						completion: NULL
			 ];
		}
		index = newIndex;
	}
	else if (distance > 50) {					//right swipe
		newIndex = MIN(index+1,2);
		if (index != newIndex){
			[UIView transitionFromView: [views objectAtIndex: index]
							toView: [views objectAtIndex: newIndex]
						  duration: 2
						   options: UIViewAnimationOptionTransitionFlipFromLeft
						completion: NULL
			 ];
		
		index = newIndex;
		}
	}
	
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void) dealloc {
	for (UIView *v in views){
		[v release];
	}
	
	[views release];
    [super dealloc];
}


@end

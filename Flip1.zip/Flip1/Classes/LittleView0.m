//
//  LittleView0.m
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LittleView0.h"
#import "TestView.h"

@implementation LittleView0

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor 
								colorWithRed: 1.0 
								green: 0.5 
								blue: 0.5 
								alpha: 1.0];
		
		CGFloat w = self.bounds.size.width;
		CGFloat h = self.bounds.size.height;
		
		CGRect f = CGRectMake(w/2-105, h/2, 210, 30);
		testView = [[TestView alloc] initWithFrame: f];
		[self addSubview: testView];
    }
    return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
		UITouch *t = [touches anyObject];
		CGPoint p = [t locationInView: self];
		testView.center = p;	//Move the view to a new location.
		
		//Can combine the above three statements to
		//view.center = [[touches anyObject] locationInView: self];
	}
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
	// Drawing code
	UIFont *f = [UIFont systemFontOfSize: 20];
	[@"This is the 1st view out of 3." drawAtPoint: CGPointZero withFont: f];
}


- (void)dealloc {
    [super dealloc];
}


@end

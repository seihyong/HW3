//
//  LittleView1.h
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LittleView1 : UIView {

}

@end

//
//  LittleView1.m
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LittleView1.h"


@implementation LittleView1


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor 
								colorWithRed: 0.5 
								green: 1.0 
								blue: 0.5 
								alpha: 1.0];
    }
    return self;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
	// Drawing code
	UIFont *f = [UIFont systemFontOfSize: 20];
	[@"This is the 2nd view out of 3." drawAtPoint: CGPointZero withFont: f];
	
	CGFloat w = self.bounds.size.width;
	CGFloat h = self.bounds.size.height;
	
	UIImage *image = [UIImage imageNamed: @"patton.jpg"];	//100 by 100
	if (image == nil) {
		NSLog(@"could not find the image");
		return;
	}
	
	CGPoint p = CGPointMake(
							(w/2 - image.size.width/2),
							h/2 - image.size.height/2
							);
	
	[image drawAtPoint: p];
}

- (void)dealloc {
    [super dealloc];
}


@end

//
//  LittleView2.m
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LittleView2.h"


@implementation LittleView2


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor 
								colorWithRed: 0.5 
								green: 0.5 
								blue: 1.0 
								alpha: 1.0];
//		tapCount = 0;
//		wearOff = 2;
		NSString *text = @"Hiii!!! ";
		CGRect b = self.bounds;
		UIFont *font = [UIFont italicSystemFontOfSize: b.size.height];
		CGSize size = [text sizeWithFont: font];
		
		CGRect f = CGRectMake(
							  b.size.width,
							  0,
							  size.width,
							  size.height
							  );
		
		label = [[UILabel alloc] initWithFrame: f];
		label.font = font;
		label.backgroundColor = [UIColor clearColor];
		label.textColor = [UIColor whiteColor];
		label.text = text;
		[self addSubview: label];
	}
    return self;
}

- (void) drawRect: (CGRect) rect {
	// Drawing code
	UIFont *g = [UIFont systemFontOfSize: 20];
	[@"This is the 3rd view out of 3." drawAtPoint: CGPointZero withFont: g];
	
	[UIView animateWithDuration: 7
						  delay: 0
						options: UIViewAnimationOptionCurveLinear
								| UIViewAnimationOptionAllowUserInteraction
								| UIViewAnimationOptionBeginFromCurrentState
					 animations: ^{
						 //Move the label far enough to the left
						 //so that it's out of the View.
						 label.center = CGPointMake(
													-label.bounds.size.width / 2,
													self.bounds.size.height / 2
													);
					 }
					 completion: NULL
	 ];
	
//
//
//- (void) noTap {	//called when no tap is currently being received
//	tapCount = 0;
//	[self setNeedsDisplay];
//}
//
//
//- (void) singleTap {	//called when a single tap is received.
//	tapCount = 1;
//	[self setNeedsDisplay];
//	
//	//After a few seconds, the single tap wears off.
//	[self performSelector: @selector(noTap) withObject: nil
//			   afterDelay: wearOff];
//}
//
//- (void) doubleTap {	//called when a double tap is received
//	tapCount = 2;
//	[self setNeedsDisplay];
//	
//	//After a few seconds, the double tap wears off.
//	[self performSelector: @selector(noTap) withObject: nil
//			   afterDelay: wearOff];
//}
//
//- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
//	NSAssert1(touches.count > 0,
//			  @"touchesBegan: touches.count == %u", touches.count);
//	
//	UITouch *t = [touches anyObject];
//	
//	if (t.tapCount == 1) {
//		[self performSelector: @selector(singleTap) withObject: nil
//				   afterDelay: 0.3];
//	} else if (t.tapCount == 2) {
//		[self doubleTap];
//	}
//}
//
//
//- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
//	NSAssert1(touches.count > 0,
//			  @"touchesBegan: touches.count == %u", touches.count);
//	
//	UITouch *t = [touches anyObject];
//	
//	if (t.tapCount == 2) {
//		[NSObject cancelPreviousPerformRequestsWithTarget: self];
//	}
//}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.

//	NSString *s = [NSString stringWithFormat: @"%u", tapCount];
//	UIFont *f = [UIFont systemFontOfSize: 6 * 72];
//	CGSize size = [s sizeWithFont: f];
//	
//	CGRect b = self.bounds;
//	CGFloat x = b.origin.x + (b.size.width - size.width) / 2;
//	CGFloat y = b.origin.y + (b.size.height - size.height) / 2;
//	[s drawAtPoint: CGPointMake(x, y) withFont: f];

}


- (void)dealloc {
    [super dealloc];
}


@end

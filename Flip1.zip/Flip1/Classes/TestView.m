//
//  TestView.m
//  Flip1
//
//  Created by SEI-HYONG PARK on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TestView.h"


@implementation TestView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor yellowColor];
    }
    return self;
}

- (void) drawRect: (CGRect) rect {
	// Drawing code
	UIFont *font = [UIFont systemFontOfSize: 20];
	[@"click anywhere to move" drawAtPoint: CGPointZero withFont: font];
}

- (void)dealloc {
    [super dealloc];
}


@end
